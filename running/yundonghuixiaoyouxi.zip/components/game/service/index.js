import initHilo from './initHilo'

export default {
  initHilo
}
