import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0377abc5 = () => interopDefault(import('..\\pages\\config.vue' /* webpackChunkName: "pages_config" */))
const _50f9db77 = () => interopDefault(import('..\\pages\\components\\Answer.vue' /* webpackChunkName: "pages_components_Answer" */))
const _7ee24036 = () => interopDefault(import('..\\pages\\components\\result.vue' /* webpackChunkName: "pages_components_result" */))
const _62f6321f = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'hash',
  base: decodeURI('./'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/config",
    component: _0377abc5,
    name: "config"
  }, {
    path: "/components/Answer",
    component: _50f9db77,
    name: "components-Answer"
  }, {
    path: "/components/result",
    component: _7ee24036,
    name: "components-result"
  }, {
    path: "/",
    component: _62f6321f,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
